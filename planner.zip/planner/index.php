
<?php
$DSN = 'mysql:host=localhost;dbname=travel';
$ConnectingDB = new PDO($DSN,'root','');
if(isset($_POST["Submit"])){
	$Fname=($_POST["fname"]);
	$Lname=($_POST["lname"]);
	$Email=($_POST["email"]);
	$Mobile=($_POST["mobile"]);
	$Dest1=($_POST["dest1"]);
	$Dest2=($_POST["dest2"]);
	$Checkin=($_POST["check_in"]);
	$Checkout=($_POST["check_out"]);
	$Duration=($_POST["duration"]);
	$Member=($_POST["member"]);
	$Price=($_POST["price"]);

	global $ConnectingDB;
    $sql="INSERT INTO travel(name,lname,email,mobile,dest1,dest2,checkin,checkout,durations,member,price)
    VALUES(:name,:lname,:email,:mobile,:dest1,:dest2,:checkin,:checkout,:durations,:member,:price)";
    $stmt = $ConnectingDB->prepare($sql);
    $stmt->bindValue(':name',$Fname);
    $stmt->bindValue(':lname',$Lname);
    $stmt->bindValue(':email',$Email);
    $stmt->bindValue(':mobile',$Mobile);
    $stmt->bindValue(':dest1',$Dest1);
    $stmt->bindValue(':dest2',$Dest2);
    $stmt->bindValue(':checkin',$Checkin);
    $stmt->bindValue(':checkout',$Checkout);
    $stmt->bindValue(':durations',$Duration);
    $stmt->bindValue(':member',$Member);
    $stmt->bindValue(':price',$Price);
    $Execute = $stmt->execute();
if($Execute){
	header('location:thanks.html');
}
// else{
	// echo " Something went wrong ! Please Try again . ";
// }
}


?>


<!doctype html>
<html class="no-js"  lang="en">

	<head>
		<!-- META DATA -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Rufina:400,700" rel="stylesheet" />

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet" />

		<!-- TITLE OF SITE -->
		<title>Travel Planner</title>

		<!-- favicon img -->
		<link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>

		<!--font-awesome.min.css-->
		<link rel="stylesheet" href="assets/css/font-awesome.min.css" />

		<!--animate.css-->
		<link rel="stylesheet" href="assets/css/animate.css" />

		<!--hover.css-->
		<link rel="stylesheet" href="assets/css/hover-min.css">

		<!--datepicker.css-->
		<link rel="stylesheet"  href="assets/css/datepicker.css" >

		<!--owl.carousel.css-->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="assets/css/owl.theme.default.min.css"/>

		<!-- range css-->
        <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />

		<!--bootstrap.min.css-->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" />

		<!-- bootsnav -->
		<link rel="stylesheet" href="assets/css/bootsnav.css"/>

		<!--style.css-->
		<link rel="stylesheet" href="assets/css/style.css" />

		<!--responsive.css-->
		<link rel="stylesheet" href="assets/css/responsive.css" />

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

	</head>

	<body>

                <!--[if lte IE 9]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade
			your browser</a> to improve your experience and security.</p>
		<![endif]-->

		<!-- main-menu Start -->
		<header class="top-area">
			<div class="header-area">
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							<div class="logo">
								<a href="index.html">
									Travel<span>Planner</span>
								</a>
							</div><!-- /.logo-->
						</div><!-- /.col-->
						<div class="col-sm-10">
							<div class="main-menu">
							
								<!-- Brand and toggle get grouped for better mobile display -->
								<div class="navbar-header">
									<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
										<i class="fa fa-bars"></i>
									</button><!-- / button-->
								</div><!-- /.navbar-header-->
								<div class="collapse navbar-collapse">		  
									<ul class="nav navbar-nav navbar-right">
										<li class="smooth-menu"><a href="#home">home</a></li>
                                                                                
										<li class="smooth-menu"><a href="#gallery">Destination</a></li>
										<li class="smooth-menu"><a href="#pack">Packages </a></li>
										<li class="smooth-menu"><a href="#spo">Special Offers</a></li>
										
										<li class="smooth-menu"><a href="#subs">subscription</a></li>
										
									</ul>
								</div><!-- /.navbar-collapse -->
							</div><!-- /.main-menu-->
						</div><!-- /.col-->
					</div><!-- /.row -->
					<div class="home-border"></div><!-- /.home-border-->
				</div><!-- /.container-->
			</div><!-- /.header-area -->

		</header><!-- /.top-area-->
		<!-- main-menu End -->

		
		<!--about-us start -->
		<section id="home" class="about-us">
			<div class="container">
				<div class="about-us-content">
					<div class="row">
						<div class="col-sm-12">
							<div class="single-about-us">
								<div class="about-us-txt">
									<h2>
										Explore the Beauty of Rajasthan

									</h2>
<h3> Rajasthan is one of the most popular tourist destinations in India, for both domestic and international tourists. Rajasthan attracts tourists for its historical forts, palaces, art and culture with its slogan "Padharo mhare desh'. Every third foreign tourist visiting India travels to Rajasthan as it is part of the Golden Triangle for tourists visiting India.</h3>
									<div class="about-btn">
										<button  class="about-view">
											explore now
										</button>
									</div><!--/.about-btn-->
								</div><!--/.about-us-txt-->
							</div><!--/.single-about-us-->
						</div><!--/.col-->
						<div class="col-sm-0">
							<div class="single-about-us">
								
							</div><!--/.single-about-us-->
						</div><!--/.col-->
					</div><!--/.row-->
				</div><!--/.about-us-content-->
			</div><!--/.container-->

		</section><!--/.about-us-->
		<!--about-us end -->




<!--travel-box start-->
<section  class="travel-box">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="single-travel-boxes">
<div id="desc-tabs" class="desc-tabs">


<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#tours" aria-controls="tours" role="tab" data-toggle="tab">
<i class="fa fa-tree"></i>
Let's Book the Trip
</a>
</li>
</ul>

<!-- Tab panes start -->
<div class="tab-content">
<div role="tabpanel" class="tab-pane active fade in" id="tours">
<div class="tab-para">

<div class="row">
<div class="col-lg-4 col-md-4 col-sm-12">
<div class="single-tab-select-box">
<form action = "" method ="post" onsubmit ="return check();">

 
 	<h2> <label for="fname">First name:</label> </h2>
 	<input required type="text" class="form-control" placeholder="Enter First Name " id="fname" style="color: #000;" name="fname"><br><br>

 	<h2> <label for="lname">Last name:</label></h2>
 	<input required type="text" class="form-control" placeholder="Enter Last Name " style="color: #000;" id="lname" name="lname"><br><br>

	 <h2> <label for="email">Email Id:</label></h2>
 	<input required type="text"  class="form-control" id="email" placeholder="Enter Email ID" style="color: #000;" name="email"><br><br>

	<h2> <label for="email">Contact Number:</label></h2>
 	<input required type="text" class="form-control" id="email" placeholder="Enter Contact Number " style="color: #000;" name="mobile"><br><br>

<h2> <label for="destination">Destination:</label></h2>
<select class="form-control " name="dest1">													<option value="default">Enter your destination city</option><!-- /.option-->						<option value="Jaipur">Jaipur</option><!-- /.option-->
	<option value="Udaipur">Udaipur</option><!-- /.option-->
	<option value="Jodhpur">Jodhpur</option><!-- /.option-->
</select><!-- /.select-->

<br>
<select class="form-control " name="dest2">													<option value="default">Enter your destination location</option><!-- /.option-->
	<option value="Indore">Indore</option><!-- /.option-->
	<option value="Bhopal">Bhopal</option><!-- /.option-->
	<option value="Pune">Pune</option><!-- /.option-->
</select><!-- /.select-->
<br>

<h2> <label for="Check in">Check in:</label></h2>
<div class="single-tab-select-box">
<div class="travel-check-icon">
<input  type="date" name="check_in" class="form-control" data-toggle="datepicker" placeholder="01-01-1997" >
<br>

<h2> <label for="Check out">Check out:</label></h2>
<div class="single-tab-select-box">
<div class="travel-check-icon">
<input  type="date" name="check_out" class="form-control" data-toggle="datepicker" placeholder="01-01-2030" >
<br>


<h2> <label for="Duration">Duration:</label></h2>
<div class="travel-select-icon">
<select class="form-control " name="duration">
	<option value="default">2</option><!-- /.option-->							      
        <option value="3">3</option><!-- /.option-->
	<option value="5">5</option><!-- /.option-->
        <option value="6">6</option><!-- /.option-->
        <option value="8">8</option><!-- /.option-->
	<option value="10">10</option><!-- /.option-->							
	<option value="15">15</option><!-- /.option-->										<option value="20">20</option><!-- /.option-->
</select><!-- /.select-->
<br>

<h2> <label for="Members">Members:</label></h2>
<div class="travel-select-icon">
<select class="form-control " name="member">												  	<option value="default">1</option><!-- /.option-->
	<option value="2">2</option><!-- /.option-->
        <option value="3">3</option><!-- /.option-->
	<option value="4">4</option><!-- /.option-->										<option value="8">8</option><!-- /.option-->									</select><!-- /.select-->
<br>

<h2> <label for="Price">Price:</label></h2>
<div class="travel-select-icon">
<select class="form-control " name="price">				              
        <option value="₹499">₹499</option><!-- /.option-->
        <option value="₹999">₹999</option><!-- /.option-->
        <option value="₹1199">₹1199</option><!-- /.option-->
        <option value="₹1499=">₹1499</option><!-- /.option-->
</select><!-- /.select-->
</div><!--/.col-->
<br>


<div class="row">
<div class="col-sm-5">
</div><!--/.col-->
<div class="col-sm-7">
<div class="about-btn travel-mrt-0 pull-right">
<button  class="about-view travel-btn" type="submit" name="Submit" onclick="send(event)">
Book Now

</button><!--/.travel-btn-->
</form>
</div><!--/.about-btn-->
</div><!--/.col-->				
</div><!--/.row-->

													
</div>
</div>
</div>



<!-- Tab panes end -->
																					
</div><!--/.desc-tabs-->
</div><!--/.single-travel-box-->
</div><!--/.col-->
</div><!--/.row-->
</div><!--/.container-->
</section><!--/.travel-box-->
<!--travel-box end-->




<!--service start-->
<section id="service" class="service">
<div class="container">
<div class="service-counter text-center">

<div class="col-md-4 col-sm-4">
<div class="single-service-box">
<div class="row">
<div class="col-sm-5">
</div><!--/.col-->
<div class="col-sm-7">
<div class="about-btn travel-mrt-0 pull-right">
<button  class="about-view travel-btn" type="submit" name="Submit" onclick="send(event)">
Book Now

</button><!--/.travel-btn-->
</form>
</div><!--/.about-btn-->
</div><!--/.col-->				
</div><!--/.row-->

													
</div>
</div>
</div>



<div class="service-content">
<h2>
<a href="#">

</a>
</h2>

</div><!--/.service-content-->

</div><!--/.single-service-box-->
</div><!--/.col-->

							

</div><!--/.statistics-counter-->	
</div><!--/.container-->
</section><!--/.service-->
<!--service end-->





<!--galley start-->
		<section id="gallery" class="gallery">
			<div class="container">
				<div class="gallery-details">
					<div class="gallary-header text-center">
						<h2>
							top destinations
						</h2>
						<p>
							Let's explore the top Destinations  
						</p>
					</div><!--/.gallery-header-->
					<div class="gallery-box">
						<div class="gallery-content">
						  	<div class="filtr-container">
						  		<div class="row">

						  			<div class="col-md-6">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g1.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													Jaipur
												</a>
												<p><span>5 places</span></p>
											</div><!-- /.item-title -->
										</div><!-- /.filtr-item -->
						  			</div><!-- /.col -->
<div class="col-md-4">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g5.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													Mount Abu
												</a>
												<p><span>3 places</span></p>
											</div> <!-- /.item-title-->
										</div><!-- /.filtr-item -->
						  			</div><!-- /.col -->

						  			<div class="col-md-6">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g2.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													Udaipur
												</a>
												<p><span>5 places</span></p>
											</div> <!-- /.item-title-->
										</div><!-- /.filtr-item -->
						  			</div><!-- /.col -->

						  			<div class="col-md-4">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g3.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													Jodhpur
												</a>
												<p><span>5 places</span></p>
											</div><!-- /.item-title -->
										</div><!-- /.filtr-item -->
						  			</div><!-- /.col -->

						  			<div class="col-md-4">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g4.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													Jaisalmer
												</a>
												<p><span>3 places</span></p>
											</div> <!-- /.item-title-->
										</div><!-- /.filtr-item -->
						  			</div><!-- /.col -->

						  			
					

						  		</div><!-- /.row -->

						  	</div><!-- /.filtr-container-->
						</div><!-- /.gallery-content -->
					</div><!--/.galley-box-->
				</div><!--/.gallery-details-->
			</div><!--/.container-->

		</section><!--/.gallery-->
		<!--gallery end-->



		
		<!--packages start-->
		<section id="pack" class="packages">
			<div class="container">
				<div class="gallary-header text-center">
					<h2>
						special packages
					</h2>
					<p>
						Lets explore the special packages  
					</p>
				</div><!--/.gallery-header-->
				<div class="packages-content">
					<div class="row">

						<div class="col-md-4 col-sm-6">
							<div class="single-package-item">
								<img src="assets/images/packages/p1.jpg" alt="package-place">
								<div class="single-package-item-txt">
									<h3>Jaipur <span class="pull-right">₹499</span></h3>
									<div class="packages-para">
										<p>
											<span>
												<i class="fa fa-angle-right"></i> 5 daays 6 nights
											</span>
											<i class="fa fa-angle-right"></i>  5 star accomodation
										</p>
										<p>
											<span>
												<i class="fa fa-angle-right"></i>  transportation
											</span>
											<i class="fa fa-angle-right"></i>  food facilities
										 </p>
									</div><!--/.packages-para-->
									<div class="packages-review">
										<p>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<span>2544 review</span>
										</p>
									</div><!--/.packages-review-->
									
								</div><!--/.single-package-item-txt-->
							</div><!--/.single-package-item-->

						</div><!--/.col-->

						<div class="col-md-4 col-sm-6">
							<div class="single-package-item">
								<img src="assets/images/packages/p2.jpg" alt="package-place">
								<div class="single-package-item-txt">
									<h3>Udaipur <span class="pull-right">₹1499</span></h3>
									<div class="packages-para">
										<p>
											<span>
												<i class="fa fa-angle-right"></i> 5 daays 6 nights
											</span>
											<i class="fa fa-angle-right"></i>  5 star accomodation
										</p>
										<p>
											<span>
												<i class="fa fa-angle-right"></i>  transportation
											</span>
											<i class="fa fa-angle-right"></i>  food facilities
										 </p>
									</div><!--/.packages-para-->
									<div class="packages-review">
										<p>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<span>2544 review</span>
										</p>
									</div><!--/.packages-review-->
									
								</div><!--/.single-package-item-txt-->
							</div><!--/.single-package-item-->

						</div><!--/.col-->
						
						<div class="col-md-4 col-sm-6">
							<div class="single-package-item">
								<img src="assets/images/packages/p3.jpg" alt="package-place">
								<div class="single-package-item-txt">
									<h3>Jodhpur <span class="pull-right">₹1199</span></h3>
									<div class="packages-para">
										<p>
											<span>
												<i class="fa fa-angle-right"></i> 5 daays 6 nights
											</span>
											<i class="fa fa-angle-right"></i>  5 star accomodation
										</p>
										<p>
											<span>
												<i class="fa fa-angle-right"></i>  transportation
											</span>
											<i class="fa fa-angle-right"></i>  food facilities
										 </p>
									</div><!--/.packages-para-->
									<div class="packages-review">
										<p>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<span>2544 review</span>
										</p>
									</div><!--/.packages-review-->
									
								</div><!--/.single-package-item-txt-->
							</div><!--/.single-package-item-->

						</div><!--/.col-->
						
						
						
						
						
						

					</div><!--/.row-->
				</div><!--/.packages-content-->
			</div><!--/.container-->

		</section><!--/.packages-->
		<!--packages end-->

		<!--discount-offer start-->
		<section class="discount-offer">
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						<div class="dicount-offer-content text-center">
							<h2>Join with us within 21 January, 2020 and get upto 40% Discount</h2>
							<div class="campaign-timer">
								<div id="timer">
									<div class="time time-after" id="days">
										<span></span>
									</div><!--/.time-->
									<div class="time time-after" id="hours">

									</div><!--/.time-->
									<div class="time time-after" id="minutes">

									</div><!--/.time-->
									<div class="time" id="seconds">

									</div><!--/.time-->
								</div><!--/.timer-->
							</div><!--/.campaign-timer-->
							


						</div><!-- /.dicount-offer-content-->
					</div><!-- /.col-->
				</div><!-- /.row-->
			</div><!-- /.container-->

		</section><!-- /.discount-offer-->
		<!--discount-offer end-->

		


		<!--special-offer start-->
		<section id="spo" class="special-offer">
			<div class="container">
				<div class="special-offer-content">
					<div class="row">
						<div class="col-sm-8">
							<div class="single-special-offer">
								<div class="single-special-offer-txt">
									<h2>Udaipur</h2>
									<div class="packages-review special-offer-review">
										<p>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<span>2544 review</span>
										</p>
									</div><!--/.packages-review-->
									<div class="packages-para special-offer-para">
										<p>
											<span>
												<i class="fa fa-angle-right"></i> 6 days 
											</span>
											<span>
												<i class="fa fa-angle-right"></i> 3 person
											</span>
											<span>
												<i class="fa fa-angle-right"></i>  5 star accomodation
											</span>
										</p>
										<p>
											<span>
												<i class="fa fa-angle-right"></i>  transportation
											</span>
											<span>
												<i class="fa fa-angle-right"></i>  food facilities
											</span>  
										</p>
										<p class="offer-para">
On the east bank of Lake Pichola, Udaipur City Palace is a glorious palace which comprises of four magnificent massive palaces and many small palaces. Each presenting a spell-biding architectural beauty with beautiful balconies, canopies and towers. The city palace complex also houses a museum.

										</p>
									</div><!--/.packages-para-->
									<div class="offer-btn-group">
										<div class="about-btn">
											
										</div><!--/.about-btn-->
										<div class="about-btn">
											<button  class="about-view packages-btn">
											Special offer!!
											</button>
										</div><!--/.about-btn-->
									</div><!--/.offer-btn-group-->
								</div><!--/.single-special-offer-txt-->
							</div><!--/.single-special-offer-->
						</div><!--/.col-->
						<div class="col-sm-4">
							<div class="single-special-offer">
								<div class="single-special-offer-bg">
									<img src="assets/images/offer/offer-shape.png" alt="offer-shape">
								</div><!--/.single-special-offer-bg-->
								<div class="single-special-shape-txt">
									<h3>special offer</h3>
									<h4><span>40%</span><br>off</h4>
									<p><span>₹999/-</span><br>regular ₹1499/-</p>
								</div><!--/.single-special-shape-txt-->
							</div><!--/.single-special-offer-->
						</div><!--/.col-->
					</div><!--/.row-->
				</div><!--/.special-offer-content-->
			</div><!--/.container-->

		</section><!--/.special-offer end-->
		<!--special-offer end-->


		
		<!--subscribe start-->
		<section id="subs" class="subscribe">
			<div class="container">
				<div class="subscribe-title text-center">
					<h2>
						Join our Subscribers List to Get Weekly Update
					</h2>
					<p>
						Subscribe Now. We will send you Best offer for your Trip 
					</p>
				</div>
				<form>
					<div class="row">
						<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
							<div class="custom-input required-group">
								<input required type="email" class="form-control" placeholder="Enter your Email Here">
								<button class="appsLand-btn subscribe-btn">Subscribe</button>
                                                                <div class="clearfix"></div>
								
							</div>

						</div>
					</div>
				</form>
			</div>

		</section>
		<!--subscribe end-->

		<!-- footer-copyright start -->
		<footer  class="footer-copyright">
			<div class="container">
				<div class="footer-content">
					<div class="row">

						<div class="col-sm-3">
							<div class="single-footer-item">
								<div class="footer-logo">
									<a href="index.html">
										Travel<span>Planner</span>
									</a>
									<p>
										Best Travel Guide
									</p>
								</div>
							</div><!--/.single-footer-item-->
						</div><!--/.col-->

						<div class="col-sm-3">
							<div class="single-footer-item">
								<h2>link</h2>
								<div class="single-footer-txt">
									<p><a href="#">home</a></p>
									<p><a href="#">destination</a></p>
									<p><a href="#">packages</a></p>
									<p><a href="#">special offers</a></p>
								
									<p><a href="#">contacts</a></p>
								</div><!--/.single-footer-txt-->
							</div><!--/.single-footer-item-->

						</div><!--/.col-->

						<div class="col-sm-3">
							<div class="single-footer-item">
								<h2>popular destination</h2>
								<div class="single-footer-txt">
									<p><a href="#">Jaipur</a></p>
									<p><a href="#">Udaipur</a></p>
									<p><a href="#">Jodhpur</a></p>
                                                                        
									
								</div><!--/.single-footer-txt-->
							</div><!--/.single-footer-item-->
						</div><!--/.col-->

						<div class="col-sm-3">
							<div class="single-footer-item text-center">
								<h2 class="text-left">contacts</h2>
								<div class="single-footer-txt text-left">
									<p>+ (91) 8349690101</p>
									<p class="foot-email"><a href="#">info@travelplanner.com</a></p>
									<p>Arera 336/A3, Bhopal, India</p>
									
								</div><!--/.single-footer-txt-->
							</div><!--/.single-footer-item-->
						</div><!--/.col-->

					</div><!--/.row-->

				</div><!--/.footer-content-->
				<hr>
				<div class="foot-icons ">
					<ul class="footer-social-links list-inline list-unstyled">
		                <li><a href="#" target="_blank" class="foot-icon-bg-1"><i class="fa fa-facebook"></i></a></li>
		                
		                <li><a href="#" target="_blank" class="foot-icon-bg-3"><i class="fa fa-instagram"></i></a></li>
		        	</ul>
		   

		        </div><!--/.foot-icons-->
				<div id="scroll-Top">
					<i class="fa fa-angle-double-up return-to-top" id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
				</div><!--/.scroll-Top-->
			</div><!-- /.container-->

		</footer><!-- /.footer-copyright-->
		<!-- footer-copyright end -->




		<script src="assets/js/jquery.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->

		<!--modernizr.min.js-->
		<script  src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>


		<!--bootstrap.min.js-->
		<script  src="assets/js/bootstrap.min.js"></script>

		<!-- bootsnav js -->
		<script src="assets/js/bootsnav.js"></script>

		<!-- jquery.filterizr.min.js -->
		<script src="assets/js/jquery.filterizr.min.js"></script>

		<script  src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>

		<!--jquery-ui.min.js-->
        <script src="assets/js/jquery-ui.min.js"></script>

        <!-- counter js -->
		<script src="assets/js/jquery.counterup.min.js"></script>
		<script src="assets/js/waypoints.min.js"></script>

		<!--owl.carousel.js-->
        <script  src="assets/js/owl.carousel.min.js"></script>

        <!-- jquery.sticky.js -->
		<script src="assets/js/jquery.sticky.js"></script>

        <!--datepicker.js-->
        <script  src="assets/js/datepicker.js"></script>

		<!--Custom JS-->
		<script src="assets/js/custom.js"></script>


	</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://smtpjs.com/v3/smtp.js">
</script>

<script type = "text/javascript">
function send(event){
event.preventDefault();

Email.send({
    Host : "smtp.elasticmail.com",
    Username : "asthas.mujmer@gmail.com",
    Password : "password",
    To : "astha.mujmer333@gmail.com",
    From : "asthas.mujmer@gmail.com",
    Subject : "Your Ticket Got Booked Successfully!",
    Body : "",
}).then(function(response){
if(response=='OK')
{
alert("Your mail has been sent!");
}
else
{
throw new Error ("Error: "+ response.statusText);
}
}
);
</script>










</html>